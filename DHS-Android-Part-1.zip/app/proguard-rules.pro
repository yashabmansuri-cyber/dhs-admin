# DHS Admin: no custom shrinking rules required.
