package com.dhs.admin;
import android.content.*; import android.webkit.JavascriptInterface; import android.app.DownloadManager; import android.net.Uri; import android.os.Environment;
public class NativeBridge{
 private final Context c; NativeBridge(Context c){this.c=c;}
 @JavascriptInterface public void setFirebaseTokens(String idToken,String refreshToken){
   c.getSharedPreferences("dhs",0).edit().putString("idToken",idToken).putString("refreshToken",refreshToken).apply();
   c.startService(new Intent(c,AlertService.class).setAction(AlertService.ACTION_START_SERVICE));
 }
 @JavascriptInterface public void newBooking(String title,String body){ c.startService(new Intent(c,AlertService.class).setAction(AlertService.ACTION_ALERT).putExtra("title",title).putExtra("body",body)); }
 @JavascriptInterface public void stopAlert(){ c.startService(new Intent(c,AlertService.class).setAction(AlertService.ACTION_STOP_ALERT)); }
 @JavascriptInterface public void saveMedia(String url){ try{DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));r.setTitle("DHS Work Media");r.setDescription("Saving DHS partner work photo/video");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES,"DHS Admin");((DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);}catch(Exception e){} }
}
