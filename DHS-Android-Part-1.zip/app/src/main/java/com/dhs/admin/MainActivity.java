package com.dhs.admin;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private WebView webView;
    private float downY;
    private boolean refreshing;
    private static final int NOTIF_REQ = 101;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(7,29,73));
        w.setNavigationBarColor(Color.rgb(7,29,73));
        if (Build.VERSION.SDK_INT >= 23) w.getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= 29) w.setStatusBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        configureWebView();
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
        }
        startMonitorIfPossible();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        webView.setBackgroundColor(Color.rgb(243,245,248));
        webView.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        webView.setOnApplyWindowInsetsListener((v,insets)->{ int top=0; if(Build.VERSION.SDK_INT>=30) top=insets.getInsets(android.view.WindowInsets.Type.statusBars()).top; else top=insets.getSystemWindowInsetTop(); v.setPadding(0,top,0,0); return insets; });
        webView.setOnTouchListener((v,e)->{
            if (e.getAction()==MotionEvent.ACTION_DOWN) downY=e.getY();
            if (e.getAction()==MotionEvent.ACTION_UP) {
                float dy=e.getY()-downY;
                if (dy>180 && !webView.canScrollVertically(-1) && !refreshing) {
                    refreshing=true; webView.reload(); webView.postDelayed(()->refreshing=false,1200); return true;
                }
            }
            return false;
        });
    }

    private void startMonitorIfPossible() {
        try {
            Intent i = new Intent(this, BookingMonitorService.class).setAction(BookingMonitorService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        try { startService(new Intent(this, BookingMonitorService.class).setAction(BookingMonitorService.ACTION_STOP_ALARM)); } catch(Exception ignored) {}
        if (webView != null) webView.evaluateJavascript("window.__nativeAppVisible&&window.__nativeAppVisible()", null);
    }

    @Override protected void onDestroy() {
        try { startService(new Intent(this, BookingMonitorService.class).setAction(BookingMonitorService.ACTION_STOP_ALARM)); } catch(Exception ignored) {}
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    public static class Bridge {
        private final Context c;
        Bridge(Context c){this.c=c;}
        @JavascriptInterface public void saveAuthTokens(String idToken, String refreshToken) {
            getPrefs(c).edit().putString("idToken", idToken).putString("refreshToken", refreshToken).apply();
            Intent i=new Intent(c,BookingMonitorService.class).setAction(BookingMonitorService.ACTION_START);
            if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);
        }
        @JavascriptInterface public void stopAlarm() {
            c.startService(new Intent(c,BookingMonitorService.class).setAction(BookingMonitorService.ACTION_STOP_ALARM));
        }
        @JavascriptInterface public void logout() {
            getPrefs(c).edit().remove("idToken").remove("refreshToken").apply();
            c.startService(new Intent(c,BookingMonitorService.class).setAction(BookingMonitorService.ACTION_STOP_ALARM));
        }
        private static android.content.SharedPreferences getPrefs(Context c){return c.getSharedPreferences("dhs_native",Context.MODE_PRIVATE);}
    }

    static android.content.SharedPreferences getPrefs(Context c){return c.getSharedPreferences("dhs_native",Context.MODE_PRIVATE);}
}
