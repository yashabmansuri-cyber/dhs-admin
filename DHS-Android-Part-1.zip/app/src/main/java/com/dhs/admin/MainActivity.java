package com.dhs.admin;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.graphics.Color;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    final int REQ=10;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,29,73)); getWindow().setNavigationBarColor(Color.rgb(7,29,73));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ);
        web=new WebView(this); web.setBackgroundColor(Color.WHITE); web.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NativeBridge(this),"DHSNative"); setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        startService(new Intent(this,AlertService.class).setAction(AlertService.ACTION_START_SERVICE));
    }
    @Override protected void onResume(){super.onResume(); if(web!=null) web.evaluateJavascript("window.DHSAppOpened&&window.DHSAppOpened()",null);}
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
