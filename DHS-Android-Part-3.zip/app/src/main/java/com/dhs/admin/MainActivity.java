package com.dhs.admin;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

public class MainActivity extends Activity {
    WebView web; float downY;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,29,73)); if(android.os.Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(true);
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);
        showSplash();
    }
    void showSplash(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(Color.rgb(7,29,73));
        TextView title=new TextView(this); title.setText("DHS"); title.setTextColor(Color.WHITE); title.setTextSize(54); title.setGravity(Gravity.CENTER); title.setTypeface(null,1);
        TextView sub=new TextView(this); sub.setText("Delhi Home Service"); sub.setTextColor(Color.WHITE); sub.setTextSize(24); sub.setGravity(Gravity.CENTER); sub.setTypeface(null,1);
        TextView w=new TextView(this); w.setText("Welcome DHS Admin"); w.setTextColor(Color.WHITE); w.setTextSize(22); w.setGravity(Gravity.CENTER); w.setPadding(0,40,0,0);
        root.addView(title,new LinearLayout.LayoutParams(-1,120)); root.addView(sub); root.addView(w);
        setContentView(root); new Handler().postDelayed(this::showWeb,3000);
    }
    void showWeb(){
        web=new WebView(this); web.setBackgroundColor(Color.WHITE); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.loadUrl("file:///android_asset/web/index.html");
        web.setOnTouchListener((v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();} else if(e.getAction()==MotionEvent.ACTION_UP && e.getY()-downY>180 && downY<180){web.reload();} return false;});
        setContentView(web);
    }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
