DHS ADMIN APP - 4 PART GITHUB BUILD

Upload ALL FOUR files with these exact names:
DHS-Android-Part-1.zip
DHS-Android-Part-2.zip
DHS-Android-Part-3.zip
DHS-Android-Part-4.zip

The existing GitHub Actions workflow that unzips DHS-Android-Part-*.zip and runs `gradle assembleDebug` can build this project.

FEATURES INCLUDED:
- Custom DHS launcher icon.
- 3 sec Loading screen, then Admin Login.
- After successful login: 3 sec Welcome DHS Admin screen with DHS worker image, then Dashboard.
- Dashboard stays below Android status bar (phone time/notification area is not covered).
- Pull down from top to refresh.
- New booking realtime listener + TAZ alert while app is active.
- Native foreground alert service keeps sound + vibration running with screen OFF/locked after a new booking is detected, until DHS Admin is opened.
- Background service polls Firestore bookings using the authenticated Firebase token; token refresh is included.
- Partner registration review: Join / Reject.
- Partner tracking: online/offline, current work, live coordinates and View Location.
- Work media: before/after photos/videos, View Full and Save Gallery request.
- Partner dispatch button next to WhatsApp in Bookings.
- Partner bills collection is included in Total Bills / Total Payments and bill history.

FIRESTORE COLLECTIONS EXPECTED:
bookings
payments
bills
partnerRegistrations
partnerStatuses
workMedia
partnerBills
partnerDispatches

PARTNER REGISTRATION FIELDS (example): name, role/service, phone, idNumber/aadhaar, selfieUrl, documents{...}, status=pending
PARTNER STATUS FIELDS (example): name/partnerName, role/service, online, currentTask/jobStatus/activity, latitude, longitude, lastSeenText
WORK MEDIA FIELDS (example): partnerName, url/downloadUrl/mediaUrl, type/mediaType=image|video, stage/workStage=before|after
PARTNER BILL FIELDS (example): partnerName, invoice, customerName, amount/total/paidAmount, paymentStatus, paymentMethod, date

IMPORTANT ANDROID SETTINGS:
After first install, allow Notifications. For Samsung/Android battery settings, set DHS Admin battery usage to Unrestricted / Allow background activity if you want the foreground alert service to remain alive reliably. Android/OEM power saving can otherwise stop background services.
