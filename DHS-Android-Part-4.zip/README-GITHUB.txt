DHS Admin Android - 4 part GitHub upload

Upload ALL FOUR ZIP files to the ROOT of a new GitHub repository using Add file -> Upload files.
After all 4 parts are uploaded, open Actions -> Build DHS Admin APK -> Run workflow.
When the build finishes, open the workflow run -> Artifacts -> DHS-Admin-APK and download app-debug.apk to your phone.

The workflow reconstructs the Android project from the four ZIP parts and builds the APK.
