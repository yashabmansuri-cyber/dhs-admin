# DHS Admin Android 2.0

Features:
- DHS launcher icon
- 3 second Welcome DHS Admin splash with DHS worker illustration
- Android 15 status-bar safe layout
- Pull down at top to refresh the app
- Native background booking monitor while the admin service is running
- Repeating sharp alert sound + vibration for new Firestore bookings
- Alert stops as soon as DHS Admin is opened/focused
- Notification remains available when screen is off

Build:
`gradle assembleDebug --no-daemon`

The GitHub workflow in `.github/workflows/build-apk.yml` assembles the four ZIP parts before building the APK.
