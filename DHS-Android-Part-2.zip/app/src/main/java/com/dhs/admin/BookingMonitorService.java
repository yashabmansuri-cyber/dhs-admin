package com.dhs.admin;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class BookingMonitorService extends Service {
    public static final String ACTION_START="START";
    public static final String ACTION_STOP_ALARM="STOP_ALARM";
    private static final String PROJECT="dhs-delhi-home-service";
    private static final String API_KEY="AIzaSyDySwVvKkMdVDfQZEWO4wPl7tPThrlmnqQ";
    private static final String CHANNEL_MONITOR="dhs_monitor";
    private static final String CHANNEL_ALERT="dhs_alert";
    private Handler h=new Handler(Looper.getMainLooper());
    private Runnable poller;
    private MediaPlayer player;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private boolean running;
    private boolean seeded;

    @Override public void onCreate(){super.onCreate(); vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE); createChannels();}
    private void createChannels(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel m=new NotificationChannel(CHANNEL_MONITOR,"DHS Background Monitor",NotificationManager.IMPORTANCE_LOW); m.setSound(null,null); m.setShowBadge(false); nm.createNotificationChannel(m);
            NotificationChannel a=new NotificationChannel(CHANNEL_ALERT,"DHS New Booking Alerts",NotificationManager.IMPORTANCE_HIGH);
            a.setDescription("Urgent new DHS booking alerts"); a.enableVibration(true); a.setVibrationPattern(new long[]{0,250,120,250,120,400});
            AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            a.setSound(null,aa); nm.createNotificationChannel(a);
        }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String a=intent==null?ACTION_START:intent.getAction();
        if(ACTION_STOP_ALARM.equals(a)){stopAlarm(); return START_STICKY;}
        startForegroundNow(); startPolling(); return START_STICKY;
    }
    private void startForegroundNow(){
        Intent open=new Intent(this,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_MONITOR):new Notification.Builder(this);
        b.setSmallIcon(com.dhs.admin.R.drawable.dhs_icon).setContentTitle("DHS Admin").setContentText("New booking monitor active").setOngoing(true).setContentIntent(pi).setCategory(Notification.CATEGORY_SERVICE);
        startForeground(9001,b.build());
    }
    private void startPolling(){
        if(running)return; running=true;
        poller=new Runnable(){public void run(){pollOnce(); if(running)h.postDelayed(this,7000);}}; h.post(poller);
    }
    private void pollOnce(){
        new Thread(()->{
            try{
                String token=getToken(); if(token==null||token.isEmpty())return;
                URL u=new URL("https://firestore.googleapis.com/v1/projects/"+PROJECT+"/databases/(default)/documents/bookings?pageSize=50");
                HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("GET"); c.setRequestProperty("Authorization","Bearer "+token); c.setConnectTimeout(10000); c.setReadTimeout(10000);
                int code=c.getResponseCode();
                if(code==401){ token=refreshToken(); if(token==null)return; c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("GET"); c.setRequestProperty("Authorization","Bearer "+token); c.setConnectTimeout(10000); c.setReadTimeout(10000); code=c.getResponseCode(); }
                if(code!=200)return;
                String body=read(c.getInputStream()); JSONObject root=new JSONObject(body); JSONArray docs=root.optJSONArray("documents"); if(docs==null)return;
                Set<String> old=loadSeen(); Set<String> now=new HashSet<>(); List<JSONObject> fresh=new ArrayList<>();
                for(int i=0;i<docs.length();i++){JSONObject d=docs.getJSONObject(i);String name=d.optString("name");String id=name.substring(name.lastIndexOf('/')+1);now.add(id);if(!old.contains(id))fresh.add(d);}
                if(!seeded && old.isEmpty()){saveSeen(now);seeded=true;return;}
                if(!fresh.isEmpty()){
                    saveSeen(now); JSONObject d=fresh.get(0); String customer=field(d,"name","customerName","Customer"); String service=field(d,"service","serviceType","Service"); String phone=field(d,"phone","customerPhone","");
                    h.post(()->newBooking(customer,service,phone));
                } else saveSeen(now);
            }catch(Exception ignored){}
        }).start();
    }
    private void newBooking(String customer,String service,String phone){
        startAlarm();
        Intent open=new Intent(this,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,2,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ALERT):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.dhs_icon).setContentTitle("🔔 NEW DHS BOOKING").setContentText(customer+" · "+service+(phone.isEmpty()?"":" · "+phone)).setStyle(new Notification.BigTextStyle().bigText("New customer booking received.\n"+customer+"\n"+service+(phone.isEmpty()?"":"\n"+phone))).setAutoCancel(false).setOngoing(true).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setContentIntent(pi);
        if(Build.VERSION.SDK_INT<26){b.setVibrate(new long[]{0,250,120,250,120,400});}
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7007,b.build());
    }
    private void startAlarm(){
        try{stopAlarm();
            player=MediaPlayer.create(this,R.raw.dhs_ring); if(player!=null){player.setLooping(true);player.setAudioStreamType(AudioManager.STREAM_ALARM);player.start();}
            if(vibrator!=null){long[] p={0,280,160,280,160,500}; if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createWaveform(p,0));else vibrator.vibrate(p,0);}
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"DHSAdmin:bookingAlarm"); wakeLock.acquire(10*60*1000L);
        }catch(Exception ignored){}
    }
    private void stopAlarm(){
        try{if(player!=null){if(player.isPlaying())player.stop();player.release();player=null;}}catch(Exception ignored){}
        try{if(vibrator!=null)vibrator.cancel();}catch(Exception ignored){}
        try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();wakeLock=null;}catch(Exception ignored){}
        try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(7007);}catch(Exception ignored){}
    }
    private String getToken(){return MainActivity.getPrefs(this).getString("idToken",null);}
    private String refreshToken(){
        try{
            String rt=MainActivity.getPrefs(this).getString("refreshToken",null); if(rt==null)return null;
            URL u=new URL("https://securetoken.googleapis.com/v1/token?key="+API_KEY); HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            String q="grant_type=refresh_token&refresh_token="+URLEncoder.encode(rt,"UTF-8");c.getOutputStream().write(q.getBytes("UTF-8"));
            if(c.getResponseCode()!=200)return null; JSONObject o=new JSONObject(read(c.getInputStream()));String id=o.optString("id_token",null);String nr=o.optString("refresh_token",rt); if(id!=null)MainActivity.getPrefs(this).edit().putString("idToken",id).putString("refreshToken",nr).apply();return id;
        }catch(Exception e){return null;}
    }
    private Set<String> loadSeen(){Set<String> s=new HashSet<>();String x=MainActivity.getPrefs(this).getString("seen","");if(!x.isEmpty())s.addAll(Arrays.asList(x.split(",")));return s;}
    private void saveSeen(Set<String> s){StringBuilder b=new StringBuilder();int n=0;for(String x:s){if(n++>=200)break;if(b.length()>0)b.append(',');b.append(x);}MainActivity.getPrefs(this).edit().putString("seen",b.toString()).apply();}
    private String field(JSONObject d,String... keys){try{JSONObject f=d.optJSONObject("fields");for(String k:keys){if(f!=null&&f.has(k)){JSONObject v=f.getJSONObject(k);for(String t:new String[]{"stringValue","integerValue","doubleValue","booleanValue","timestampValue"})if(v.has(t))return v.optString(t);}}}catch(Exception ignored){}return keys.length>0?keys[keys.length-1]:"";}
    private static String read(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return b.toString();}
    @Override public void onDestroy(){running=false;if(poller!=null)h.removeCallbacks(poller);stopAlarm();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
